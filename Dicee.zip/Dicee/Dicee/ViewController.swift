//
//  ViewController.swift
//  Dicee
//
//  Created by Karim on 2/11/18.
//  Copyright © 2018 Karim. All rights reserved.
//

import UIKit

class ViewController: UIViewController {
    @IBOutlet weak var diceViewImage1: UIImageView!
    @IBOutlet weak var diceViewImage2: UIImageView!
    @IBOutlet weak var totalPlayerLabel: UILabel!
    @IBOutlet weak var totalIPhoneLabel: UILabel!
    @IBOutlet weak var winnerLabel: UILabel!
    
    var diceRandomIndex1: Int = 0
    var diceRandomIndex2: Int = 0
    
    var diceArray = ["dice1","dice2","dice3","dice4","dice5","dice6"]
    override func viewDidLoad() {
        super.viewDidLoad()
        
    }
    
    
    
    @IBAction func rollButtonPressed(_ sender: Any) {
        diceRandomIndex1 = Int(arc4random_uniform(6))
        diceRandomIndex2 = Int(arc4random_uniform(6))
        
        diceViewImage1.image = UIImage(named: diceArray[diceRandomIndex1])
        diceViewImage2.image = UIImage(named: diceArray[diceRandomIndex2])
        
        totalPlayerLabel.text = String(diceRandomIndex1 + 1)
        totalIPhoneLabel.text = String(diceRandomIndex2 + 1)
        
        if diceRandomIndex1 > diceRandomIndex2{
            winnerLabel.text = "Player"
        } else if diceRandomIndex1 == diceRandomIndex2 {
            winnerLabel.text = "Equal Score"
        } else {
            winnerLabel.text = "iPhone"
        }
    }
    
    
}
